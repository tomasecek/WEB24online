
# Vektorová grafika
* cílem je zkusit přímo zápisem do html souboru vytvořit vektorovou grafiku
* doporučené postupy: čisté html, lze použít bootstrap a css
* využijte všech šest předpřipravených příkladů
  1-svg-jednoduche.html 
  2-svg-semantika.html
  3-svg-v-souboru.html
  4-svg-styly.html
  5-svg-a-css-layout.html
  6-svg-a-bootstrap.html 
* funkční navigace "zpět" na všech Stánkách!
* hotová konstrukce loga může obsahovat třeba jen tři geometrické tvary
  (nemělo by se jednát o rastrovou grafiku u vnitř vektorové grafiky pomocí
  nástrojů Adobe atp...), vlastní téma nebo logo školy.
* svojí kresbu provést na hodině aktivně při výuce pomocí příkladu 6
* při výuce rozkopírovat kresbu do vektory1.svg 1 2 3 4 5
* při výuce svou grafiku rozkopírovat a různě modifikovat všech šest příkladů
* do portfolia stránek přidat Vektorová grafika, logo pslib
* vše umístit do svých složek na github, správa v Teams na konci hodiny s odkazem stránku (web24).

pokud mate hotovo, využijte čas k vyřízeni komunikace, nebo třeba i hry,
nerušte, spis pomáhejte spolužákům, i při takovéto činnosti se lze něco naučit.
hlučná volna diskuze je nevhodný přistup, neodcházejte dříve z výuky.
